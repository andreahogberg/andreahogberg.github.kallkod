<script>
  import BlogArticles from '../components/BlogArticles.vue'
  import Image from '../components/Image.vue'

  export default {
    components: {
      BlogArticles,
      Image
    }
  }
</script>

<template>
  <h1>Home</h1>

  <Image />
  <BlogArticles />
</template>
